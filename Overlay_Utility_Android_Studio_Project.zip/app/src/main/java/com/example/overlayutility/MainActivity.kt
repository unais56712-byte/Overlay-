package com.example.overlayutility
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val l = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,48,32,32) }
  l.addView(TextView(this).apply { text="Overlay Utility"; textSize=24f })
  l.addView(TextView(this).apply { text="Simple draggable information panel. It does not modify game files or provide gameplay cheats."; textSize=16f; setPadding(0,16,0,20) })
  l.addView(Button(this).apply { text="Grant overlay permission"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
   else Toast.makeText(this@MainActivity,"Permission already granted",Toast.LENGTH_SHORT).show()
  }})
  l.addView(Button(this).apply { text="Show floating panel"; setOnClickListener {
   if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity,OverlayService::class.java))
   else Toast.makeText(this@MainActivity,"Grant overlay permission first",Toast.LENGTH_SHORT).show()
  }})
  l.addView(Button(this).apply { text="Hide floating panel"; setOnClickListener { stopService(Intent(this@MainActivity,OverlayService::class.java)) }})
  setContentView(l)
 }
}