package com.example.overlayutility
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
 private lateinit var wm: WindowManager
 private var panel: TextView? = null
 private val handler = Handler(Looper.getMainLooper())
 private val updater = object: Runnable {
  override fun run() {
   panel?.text = "DEVICE OVERLAY\nTime: " + SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date()) + "\nStatus: Active\nGame files: Untouched"
   handler.postDelayed(this,1000)
  }
 }
 override fun onCreate() {
  super.onCreate()
  wm = getSystemService(WINDOW_SERVICE) as WindowManager
  val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val v = TextView(this).apply { setTextColor(Color.WHITE); textSize=13f; setPadding(20,16,20,16); setBackgroundColor(0xCC20242B.toInt()) }
  val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=24; y=180 }
  var sx=0; var sy=0; var tx=0f; var ty=0f
  v.setOnTouchListener { _, e -> when(e.action) {
   MotionEvent.ACTION_DOWN -> { sx=p.x; sy=p.y; tx=e.rawX; ty=e.rawY; true }
   MotionEvent.ACTION_MOVE -> { p.x=sx+(e.rawX-tx).toInt(); p.y=sy+(e.rawY-ty).toInt(); wm.updateViewLayout(v,p); true }
   else -> false
  }}
  panel=v; wm.addView(v,p); handler.post(updater)
 }
 override fun onDestroy() { handler.removeCallbacks(updater); panel?.let { wm.removeView(it) }; panel=null; super.onDestroy() }
 override fun onBind(intent: Intent?): IBinder? = null
}