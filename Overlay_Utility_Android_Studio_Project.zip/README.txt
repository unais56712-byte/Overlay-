Overlay Utility - Android Studio project

Features:
- Draggable floating information panel with local time and active status.
- Does not modify PUBG/game files, load PAK files, provide ESP/aim/headshot features, or bypass anti-cheat.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select Build > Build APK(s).
4. Install the generated APK.
5. Open Overlay Utility, grant Display over other apps, then tap Show floating panel.
6. To remove it, reopen the app and tap Hide floating panel.

This ZIP contains source code, not a prebuilt APK. Android Studio and Android SDK are needed to build it.
